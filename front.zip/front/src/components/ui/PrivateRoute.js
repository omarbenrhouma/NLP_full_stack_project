import React, { useState, useEffect } from "react";
import { getOffres } from "../../services/api";

const OffresList = () => {
  const [offres, setOffres] = useState([]);

  useEffect(() => {
    const fetchOffres = async () => {
      try {
        const response = await getOffres();
        setOffres(response.data);
      } catch (error) {
        console.error("Erreur lors du chargement des offres :", error);
      }
    };
    fetchOffres();
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Offres disponibles</h2>
      <ul className="space-y-4">
        {offres.map((offre) => (
          <li key={offre._id} className="border p-4 rounded-md shadow-md">
            <h3 className="text-xl font-semibold">{offre.titre}</h3>
            <p>{offre.description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default OffresList;
