import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./button";
import OffreForm from "./OffreForm";
import CVUploader from "./CVUploader";
import OffresList from "./OffresList";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

const Dashboard = () => {
  const [view, setView] = useState("home");
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
  };

  const renderContent = () => {
    switch (view) {
      case "postuler":
        return <CVUploader />;
      case "recruter":
        return <OffreForm />;
      case "offres":
        return <OffresList />;
      default:
        return (
          <motion.div
            className="text-center mt-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <h2 className="text-3xl font-bold text-gray-700 mb-6">
              Bienvenue sur SmartRecruit
            </h2>
            <p className="mb-10 text-gray-500">Choisissez une action :</p>
            <div className="flex flex-wrap justify-center gap-6">
              <Button
                onClick={() => setView("postuler")}
                className="bg-green-500 hover:bg-green-600"
              >
                Postuler
              </Button>
              <Button
                onClick={() => setView("recruter")}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Publier une offre
              </Button>
              <Button
                onClick={() => setView("offres")}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Voir les offres
              </Button>
            </div>
          </motion.div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-200">
      <nav className="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-50">
        <h1
          className="text-2xl font-bold text-indigo-600 cursor-pointer"
          onClick={() => setView("home")}
        >
          SmartRecruit
        </h1>
        <div className="space-x-4 flex items-center">
          {user ? (
            <>
              <span className="text-gray-700 font-medium">
                {user.nom} ({user.role})
              </span>
              <Button onClick={() => navigate("/profil")} className="bg-indigo-600">
                Profil
              </Button>
              <Button onClick={handleLogout} className="bg-red-500">
                Déconnexion
              </Button>
            </>
          ) : (
            <>
              <Button
                onClick={() => navigate("/login")}
                className="bg-indigo-600"
              >
                Connexion
              </Button>
              <Button
                onClick={() => navigate("/register")}
                className="bg-gray-600"
              >
                Créer un compte
              </Button>
            </>
          )}
        </div>
      </nav>
      <main className="p-6">
        <AnimatePresence mode="wait">{renderContent()}</AnimatePresence>
      </main>
    </div>
  );
};

export default Dashboard;
