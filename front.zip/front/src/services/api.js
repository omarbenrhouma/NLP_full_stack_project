import axios from "axios";

const BASE_URL = "http://localhost:5000/api";

// Auth
export const loginUser = (data) => axios.post(`${BASE_URL}/auth/login`, data);
export const registerUser = (data) => axios.post(`${BASE_URL}/auth/register`, data);

// Entreprises / Offres
export const addEntreprise = (data) => axios.post(`${BASE_URL}/entreprises/ajouter`, data);
export const addOffre = (data) => axios.post(`${BASE_URL}/offres/ajouter`, data);

// Candidatures
export const uploadCV = (formData) =>
  axios.post(`${BASE_URL}/candidatures/upload`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });

export const getOffres = () => axios.get(`${BASE_URL}/offres`);
export const getCandidatures = () => axios.get(`${BASE_URL}/candidatures`);
